# SunnyCorp — Original Screenshot Evidence

**Status:** These screenshots were copied from the user-provided images in the SunnyCorp ChatGPT conversation. They are authentic captures of the lab, not synthetic or recreated output.

Some images were cropped to remove unrelated blank areas. No command output or result value was changed.

| Phase | Screenshot | What it proves |
|---|---|---|
| Phase 1 | [**01-network-connectivity.png**](evidence/01-network-connectivity.png) | Successful ping replies to 10.10.10.10 from a lab workstation. |
| Phase 2 | [**02-active-directory-promotion.png**](evidence/02-active-directory-promotion.png) | Windows Server reports successful Domain Controller configuration. |
| Phase 2 | [**03-domain-joined-workstation.png**](evidence/03-domain-joined-workstation.png) | AD PowerShell shows SUNNY-CL01 joined to the domain (at the Computers container stage). |
| Phase 3 | [**04-fifty-department-employees.png**](evidence/04-fifty-department-employees.png) | PowerShell shows ten employees in each of five departments, 50 total. |
| Phase 3 | [**05-department-security-groups.png**](evidence/05-department-security-groups.png) | Active Directory security groups for the five business departments. |
| Phase 4 | [**06-hr-network-drive.png**](evidence/06-hr-network-drive.png) | The HR employee sees the automatically mapped H: network drive. |
| Phase 4 | [**07-finance-access-denied.png**](evidence/07-finance-access-denied.png) | The tested account is denied access to the Finance file share. |
| Phase 4 | [**08-hr-file-access-audit.png**](evidence/08-hr-file-access-audit.png) | Windows Security Event 4663 records access to an HR file. |
| Phase 5 | [**09-disabled-user-login.png**](evidence/09-disabled-user-login.png) | Windows rejects a sign-in attempt to the disabled test account. |
| Phase 5 | [**10-separated-admin-identity.png**](evidence/10-separated-admin-identity.png) | Dedicated admin account is in Workstation Admins but not Domain Admins. |
| Phase 5 | [**11-encrypted-laps-backup.png**](evidence/11-encrypted-laps-backup.png) | Windows LAPS shows encrypted AD password backup and Domain Admins as authorized decryptor; no password visible. |
| Phase 5 | [**12-defender-pua-blocking.png**](evidence/12-defender-pua-blocking.png) | Microsoft Defender PUAProtection value is 1, indicating blocking mode. |
| Phase 5 | [**13-firewall-effective-logging.png**](evidence/13-firewall-effective-logging.png) | Effective Domain Firewall settings show blocked-traffic logging enabled and 20 MB maximum. |
| Phase 5 | [**14-remote-it-administration.png**](evidence/14-remote-it-administration.png) | Authenticated remote PowerShell executes hostname and whoami on SUNNY-CL01. |
| Phase 6 | [**15-failed-login-detection.png**](evidence/15-failed-login-detection.png) | The locally executed detection script flags three failed administrator logins. |
| Phase 6 | [**16-centralized-event-forwarding.png**](evidence/16-centralized-event-forwarding.png) | The central collector receives 4624 and 4672 authentication events from SUNNY-CL01. |
| Phase 6 | [**17-forwarded-failed-logins.png**](evidence/17-forwarded-failed-logins.png) | SUNNY-FS01 receives two failed-logon events targeting a test admin account. |
| Phase 6 | [**18-account-lifecycle-events.png**](evidence/18-account-lifecycle-events.png) | Windows Security logs show user account creation (4720) and disablement (4725). |
| Phase 6 | [**19-admin-group-change-event.png**](evidence/19-admin-group-change-event.png) | Event 4728 documents an authorized group membership change and the administrator who made it. |

## Review before making GitHub public

- [ ] Verify no plaintext passwords, temporary credential files or tokens appear
- [ ] Review screenshots for personal information
- [ ] Confirm captions accurately match what was observed
- [ ] Keep the original images in case an audit requires uncropped evidence
- [ ] Avoid presenting the lab as a real company or as evidence of an actual intrusion

**Known limits:** Some later failed-logon forwarding remained unverified. The WEF screenshots demonstrate actual delivery of earlier events, not full lossless delivery.

The CSV manifest records the exact original chat screenshot filename, the handling applied, and each packaged image's SHA-256 hash.
